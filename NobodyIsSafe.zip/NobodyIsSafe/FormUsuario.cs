﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NobodyIsSafe
{
    public partial class FormUsuario : Form
    {
        public FormUsuario()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FormUsuario_Load(object sender, EventArgs e)
        {
            Usuario usu = new Usuario();
            List<Usuario> usuarios = usu.listausuario();
            dgvUsuario.DataSource = usuarios;
        }

        private void btnCadastrar_Click(object sender, EventArgs e)
        {
            try
            {
                Usuario usuario = new Usuario();
                usuario.Inserir(txtNome.Text, txtLogin.Text, txtSenha.Text, txtCelular.Text,txtEmail.Text);
                MessageBox.Show("Usuário cadastrado com sucesso!", "Cadastro", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Usuario> usu = usuario.listausuario();
                dgvUsuario.DataSource = usu;
                txtCpf.Text = "";
                txtNome.Text = "";
                txtLogin.Text = "";
                txtSenha.Text = "";
                txtCelular.Text = "";
                txtEmail.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnLocalizar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtCpf.Text.Trim());
                Usuario usuario = new Usuario();
                usuario.Localiza(id);
                txtNome.Text = usuario.nome;
                txtLogin.Text = usuario.login;
                txtSenha.Text = usuario.senha;
                txtCelular.Text = usuario.celular;
                txtEmail.Text = usuario.email;
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtCpf.Text.Trim());
                Usuario usuario = new Usuario();
                usuario.Atualizar(id, txtNome.Text, txtLogin.Text, txtSenha.Text, txtCelular.Text,txtEmail.Text);
                MessageBox.Show("Usuário atualizado com sucesso!", "Edição", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Usuario> usu = usuario.listausuario();
                dgvUsuario.DataSource = usu;
                txtCpf.Text = "";
                txtNome.Text = "";
                txtLogin.Text = "";
                txtSenha.Text = "";
                txtCelular.Text = "";
                txtEmail.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(txtId.Text.Trim());
                Usuario usuario = new Usuario();
                usuario.Exclui(id);
                MessageBox.Show("Usuário excluído com sucesso!", "Exclusão", MessageBoxButtons.OK, MessageBoxIcon.Information);
                List<Usuario> usu = usuario.listausuario();
                dgvUsuario.DataSource = usu;
                txtCpf.Text = "";
                txtNome.Text = "";
                txtLogin.Text = "";
                txtSenha.Text = "";
                txtCelular.Text = "";
                txtEmail.Text = "";
                ClassConecta.FecharConexao();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnLimpaCampos_Click(object sender, EventArgs e)
        {
            txtCpf.Text = "";
            txtNome.Text = "";
            txtLogin.Text = "";
            txtSenha.Text = "";
            txtCelular.Text = "";
            txtEmail.Text = "";
        }
    }
}
